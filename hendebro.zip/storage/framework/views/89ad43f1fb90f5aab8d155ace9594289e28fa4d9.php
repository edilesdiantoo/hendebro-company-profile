<div class="row">
    <div class="col mb-3">
        <label for="namaLenkap" class="form-label">Nama Menu Hdr</label>
        <input type="hidden" name="id" id="id" value="<?php echo e($getMenuhdrData->id); ?>">
        <input type="text" name="hdr_name" id="hdr_name" class="form-control" placeholder="Nama Lengkap"
            value="<?php echo e(old('name', $getMenuhdrData->hdr_name)); ?>" />
        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="invalid-feedback"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
</div>
<div class="row">
    <div class="col mb-3">
        <label for="username" class="form-label">Title</label>
        <input type="text" id="title" class="form-control" placeholder="title"
            value="<?php echo e(old('name', $getMenuhdrData->title)); ?>" />
    </div>
</div>

<?php /**PATH C:\xampp7.4\htdocs\hende-bro\resources\views/mngContent/modal/editMenuHdr.blade.php ENDPATH**/ ?>