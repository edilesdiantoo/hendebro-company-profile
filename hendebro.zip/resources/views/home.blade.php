{{-- @extends('layouts.main')

@section('container')
    <h1>Halaman Home</h1>
@endsection --}}

<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Solusi Sistem UMKM atau Perusahaan</title>
    <link rel="icon" type="image/x-icon" href="assets/icon/favicon.ico">
    <!-- <link href="dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous"> -->
    <link rel="stylesheet" type="text/css" href="css/costum.css">
    <style type="text/css">
        html {
            font-family: 'Poppins';
            /*font-size: 14px;*/
        }

        .fs-7 {
            font-size: 4rem;
        }

        .fs-8 {
            font-size: 2.3rem;
        }

        .dot {
            height: 10px;
            width: 10px;
            background-color: #ffc107;
            border-radius: 50%;
            display: inline-block;
        }

        /*  ---------------------------------------  */
        .ltor-container {
            height: 150px;
            overflow: hidden;
        }

        .ltor-container .ltor {
            top: 0;
            left: 100%;
            width: 100%;
            overflow: hidden;
            position: absolute;
            white-space: nowrap;
            animation: ltor 30s linear infinite;
        }

        .ltor-container .ltor2 {
            animation-delay: 15s;
        }

        @keyframes ltor {
            0% {
                left: 100%;
            }

            100% {
                left: -110%;
            }
        }

        .rtol-container {
            height: 150px;
            overflow: hidden;
        }

        .rtol-container .rtol {
            top: 0;
            right: 100%;
            width: 100%;
            overflow: hidden;
            position: absolute;
            white-space: nowrap;
            animation: rtol 30s linear infinite;
        }

        .rtol-container .rtol2 {
            animation-delay: 15s;
        }

        @keyframes rtol {
            0% {
                right: 100%;
            }

            100% {
                right: -110%;
            }
        }

        .scroll-parent {
            position: relative;
            width: 100%;
            height: 35rem;
            overflow-y: hidden;
        }

        .scroll-element {
            width: inherit;
            height: inherit;
            position: absolute;
            left: 0%;
            top: 0%;
        }

        .utama {
            animation: utama 10s linear infinite;
        }

        .kedua {
            animation: kedua 10s linear infinite;
        }

        @keyframes utama {
            0% {
                top: 0%;
            }

            50% {
                top: -50%;
            }

            100% {
                top: 0%;
            }
        }

        @keyframes kedua {
            0% {
                top: -50%;
            }

            50% {
                top: 0%;
            }

            100% {
                top: -50%;
            }
        }

        /*  animasi gambar  */
        .anim-1 {
            position: absolute;
            top: 50%;
            left: 60%;
            animation: anim-1 2s ease-out;
        }

        @keyframes anim-1 {
            0% {
                transform: scale(0);
            }

            20% {
                transform: scale(1.2);
            }

            22% {
                transform: scale(1);
            }
        }


        /*  animasi gambar  */
        .anim-2 {
            position: absolute;
            top: 30%;
            left: 60%;
            animation: anim-2 2s ease-out;
        }

        @keyframes anim-2 {
            0% {
                transform: scale(0);
            }

            20% {
                transform: scale(1.1);
            }

            22% {
                transform: scale(1);
            }
        }
    </style>
</head>

<body>

    <!-- navbar -->
    <nav class="py-3 fixed-top" style="backdrop-filter: blur(5px); background-color: rgba(28,123,138,0.6);">
        <div class="container">
            <div class="row">
                <div class="d-flex align-items-center">
                    <a href="" class=""><img src="assets/logo/logo-v3.png"
                            style="width: 50px; height: 50px;"></a>
                    <div class="ms-auto">
                        @foreach ($get_hdr_data as $key => $hdr)
                            <a href=""
                                class="text-white text-decoration-none px-4 fw-semibold">{{ $hdr->hdr_name }}</a>
                            {{-- <a href="" class="text-white text-decoration-none px-4 fw-semibold">Source Code</a>
                            <a href="" class="text-white text-decoration-none px-4 fw-semibold">Hosting</a>
                            <a href="" class="text-white text-decoration-none px-4 fw-semibold">Product</a> --}}
                        @endforeach
                    </div>
                </div>
            </div>
        </div>
    </nav>

    <!-- main -->
    <div class="bg-primary py-5">
        <div class="container pt-5">
            <div class="row align-items-center">
                <div class="col">
                    <div class="text-white fw-bold fs-7">hendebro.</div>
                    <div class="text-white fw-semibold fs-8 pb-1">Software Agency</div>
                    <div class="text-white text-opacity-75 py-3" style="text-align: justify;">Kami adalah perusahaan
                        rintisan
                        digital yang bergerak dibidang pengembang perangkat lunak seperti website dan mobile app, solusi
                        terbaik
                        untuk permasalahan sistem pribadi ataupun perusahaan anda.</div>
                    <div class="row gx-4 pt-4">
                        <div class="col">
                            <div class="d-grid"><button class="btn btn-warning text-teal fw-semibold rounded-3"
                                    style="--bs-btn-padding-y: .8rem;">Get Started</button></div>
                        </div>
                        <div class="col">
                            <div class="d-grid">
                                <button class="btn btn-outline-warning rounded-3" style="--bs-btn-padding-y: .8rem;">
                                    <div class="d-flex align-items-center justify-content-center">
                                        <img src="assets/icon/play-y.svg">
                                        <span class="ps-2 fw-semibold">Learn More</span>
                                    </div>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col text-end">
                    <!-- <img src="assets/img/anim-1.png" class="anim-1"> -->
                    <!-- <img src="assets/img/anim-2.png" class="anim-2"> -->
                    <img src="assets/img/breadcumb.png">
                </div>
            </div>
        </div>
    </div>

    <!-- client -->
    <div class="pt-5 text-center">
        <div class="container">
            <div class="bg-light rounded-4 row">
                <div class="col">
                    <img src="assets/img/client.png">
                </div>
            </div>
        </div>
    </div>

    <!-- informasi -->
    <div class="pt-5">
        <div class="container">
            <div class="row text-center">
                <div class="col">
                    <div class="text-primary fs-1 fw-semibold">Find the best solution to your business.</div>
                    <div class="text-grey">Gunakan beberapa pilihan yang telah kami berikan dibawah ini</div>
                </div>
            </div>
            <div class="row gx-4 pt-5">
                <div class="col">
                    <div class="bg-teal rounded-4 bg-opacity-50 p-4">
                        <div class="d-flex align-items-center">
                            <div class="dot"></div>
                            <div class="ps-1 fw-semibold text-grey">Blog</div>
                        </div>
                        <div class="ps-1 fw-bold fs-4 text-black text-opacity-75">Lifetime Access</div>
                    </div>
                </div>
                <div class="col">
                    <div class="bg-teal rounded-4 bg-opacity-50 p-4">
                        <div class="d-flex align-items-center">
                            <div class="dot"></div>
                            <div class="ps-1 fw-semibold text-grey">Source Code</div>
                        </div>
                        <div class="ps-1 fw-bold fs-4 text-black text-opacity-75">Freemium</div>
                    </div>
                </div>
                <div class="col">
                    <div class="bg-teal rounded-4 bg-opacity-50 p-4">
                        <div class="d-flex align-items-center">
                            <div class="dot"></div>
                            <div class="ps-1 fw-semibold text-grey">Hosting <small class="fw-normal fst-italic">mulai
                                    dari</small>
                            </div>
                        </div>
                        <div class="ps-1 fw-bold fs-4 text-black text-opacity-75">Rp 50.000</div>
                    </div>
                </div>
                <div class="col">
                    <div class="bg-teal rounded-4 bg-opacity-50 p-4">
                        <div class="d-flex align-items-center">
                            <div class="dot"></div>
                            <div class="ps-1 fw-semibold text-grey">Product <small class="fw-normal fst-italic">mulai
                                    dari</small>
                            </div>
                        </div>
                        <div class="ps-1 fw-bold fs-4 text-black text-opacity-75">Rp 1.000.000</div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- blog -->
    <div class="bg-teal mt-5 py-5">
        <div class="container">
            <div class="row">
                <div class="col">
                    <div class="text-primary fw-semibold">Find Information About Programming</div>
                    <div class="text-black fs-1 fw-bold">Temukan Infromasi Seputar Pemrograman</div>
                </div>
            </div>
            <div class="row gx-4 pt-4">
                <div class="col">
                    <div class="bg-white rounded-4 p-4">
                        <img src="https://via.placeholder.com/500x300.png?text=500x300" class="img-fluid rounded-4">
                        <div class="pt-3">
                            <div class="fw-bold text-black">UI / UX : Menggunakan Figma Sebagai Tools Utama</div>
                            <div class="fw-light text-grey">Hello people spirit of learning! Dalam flutter terdapat
                                widget elevated
                                button yang...</div>
                        </div>
                    </div>
                </div>
                <div class="col">
                    <div class="bg-white rounded-4 p-4">
                        <img src="https://via.placeholder.com/500x300.png?text=500x300" class="img-fluid rounded-4">
                        <div class="pt-3">
                            <div class="fw-bold text-black">Laravel Tutorial : Cara membuat model pada blade</div>
                            <div class="fw-light text-grey">Hello people spirit of learning! Dalam flutter terdapat
                                widget elevated
                                button yang</div>
                        </div>
                    </div>
                </div>
                <div class="col">
                    <div class="bg-white rounded-4 p-4">
                        <img src="https://via.placeholder.com/500x300.png?text=500x300" class="img-fluid rounded-4">
                        <div class="pt-3">
                            <div class="fw-bold text-black">HTML Tutorial : Mahir Menggunakan Tag HTML</div>
                            <div class="fw-light text-grey">Hello people spirit of learning! Dalam flutter terdapat
                                widget elevated
                                button yang</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- animasi card left and right -->
    <div class="pt-5">
        <div class="container">
            <div class="row text-center">
                <div class="col">
                    <!-- <div class="text-primary fw-semibold">Learn From Case Studies</div> -->
                    <!-- <div class="text-black fs-1 fw-bold">Temukan Kode Sesuai Kebutuhan Anda</div> -->
                    <div class="text-primary fw-semibold">Update Your Skills</div>
                    <div class="text-black fs-1 fw-bold">Ada Banyak Pilihan <br> Bahasa Pemrograman</div>
                </div>
            </div>
        </div>
    </div>
    <div class="pt-5">
        <div class="position-relative d-none d-sm-block ltor-container">
            <div class="d-flex justify-content-between ltor">
                <div class="bg-teal rounded-4 p-4">
                    <div class="d-flex align-items-center">
                        <img src="https://via.placeholder.com/80x80.png?text=80x80" class="img-fluid rounded-4">
                        <div class="ps-2">
                            <div class="fw-bold text-black">Laravel</div>
                            <div class="fw-light text-grey">Back-End Development</div>
                        </div>
                    </div>
                </div>
                <div class="bg-teal rounded-4 p-4">
                    <div class="d-flex align-items-center">
                        <img src="https://via.placeholder.com/80x80.png?text=80x80" class="img-fluid rounded-4">
                        <div class="ps-2">
                            <div class="fw-bold text-black">Codeigniter</div>
                            <div class="fw-light text-grey">Back-End Development</div>
                        </div>
                    </div>
                </div>
                <div class="bg-teal rounded-4 p-4">
                    <div class="d-flex align-items-center">
                        <img src="https://via.placeholder.com/80x80.png?text=80x80" class="img-fluid rounded-4">
                        <div class="ps-2">
                            <div class="fw-bold text-black">HTML</div>
                            <div class="fw-light text-grey">Front-End Development</div>
                        </div>
                    </div>
                </div>
                <div class="bg-teal rounded-4 p-4">
                    <div class="d-flex align-items-center">
                        <img src="https://via.placeholder.com/80x80.png?text=80x80" class="img-fluid rounded-4">
                        <div class="ps-2">
                            <div class="fw-bold text-black">Javascript</div>
                            <div class="fw-light text-grey">Front-End Development</div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="d-flex justify-content-between ltor ltor2">
                <div class="bg-teal rounded-4 p-4">
                    <div class="d-flex align-items-center">
                        <img src="https://via.placeholder.com/80x80.png?text=80x80" class="img-fluid rounded-4">
                        <div class="ps-2">
                            <div class="fw-bold text-black">Laravel</div>
                            <div class="fw-light text-grey">Back-End Development</div>
                        </div>
                    </div>
                </div>
                <div class="bg-teal rounded-4 p-4">
                    <div class="d-flex align-items-center">
                        <img src="https://via.placeholder.com/80x80.png?text=80x80" class="img-fluid rounded-4">
                        <div class="ps-2">
                            <div class="fw-bold text-black">Codeigniter</div>
                            <div class="fw-light text-grey">Back-End Development</div>
                        </div>
                    </div>
                </div>
                <div class="bg-teal rounded-4 p-4">
                    <div class="d-flex align-items-center">
                        <img src="https://via.placeholder.com/80x80.png?text=80x80" class="img-fluid rounded-4">
                        <div class="ps-2">
                            <div class="fw-bold text-black">HTML</div>
                            <div class="fw-light text-grey">Front-End Development</div>
                        </div>
                    </div>
                </div>
                <div class="bg-teal rounded-4 p-4">
                    <div class="d-flex align-items-center">
                        <img src="https://via.placeholder.com/80x80.png?text=80x80" class="img-fluid rounded-4">
                        <div class="ps-2">
                            <div class="fw-bold text-black">Javascript</div>
                            <div class="fw-light text-grey">Front-End Development</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="pb-5">
        <div class="position-relative d-none d-sm-block rtol-container">
            <div class="d-flex justify-content-between rtol">
                <div class="bg-teal rounded-4 p-4">
                    <div class="d-flex align-items-center">
                        <img src="https://via.placeholder.com/80x80.png?text=80x80" class="img-fluid rounded-4">
                        <div class="ps-2">
                            <div class="fw-bold text-black">Laravel</div>
                            <div class="fw-light text-grey">Back-End Development</div>
                        </div>
                    </div>
                </div>
                <div class="bg-teal rounded-4 p-4">
                    <div class="d-flex align-items-center">
                        <img src="https://via.placeholder.com/80x80.png?text=80x80" class="img-fluid rounded-4">
                        <div class="ps-2">
                            <div class="fw-bold text-black">Codeigniter</div>
                            <div class="fw-light text-grey">Back-End Development</div>
                        </div>
                    </div>
                </div>
                <div class="bg-teal rounded-4 p-4">
                    <div class="d-flex align-items-center">
                        <img src="https://via.placeholder.com/80x80.png?text=80x80" class="img-fluid rounded-4">
                        <div class="ps-2">
                            <div class="fw-bold text-black">HTML</div>
                            <div class="fw-light text-grey">Front-End Development</div>
                        </div>
                    </div>
                </div>
                <div class="bg-teal rounded-4 p-4">
                    <div class="d-flex align-items-center">
                        <img src="https://via.placeholder.com/80x80.png?text=80x80" class="img-fluid rounded-4">
                        <div class="ps-2">
                            <div class="fw-bold text-black">Javascript</div>
                            <div class="fw-light text-grey">Front-End Development</div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="d-flex justify-content-between rtol rtol2">
                <div class="bg-teal rounded-4 p-4">
                    <div class="d-flex align-items-center">
                        <img src="https://via.placeholder.com/80x80.png?text=80x80" class="img-fluid rounded-4">
                        <div class="ps-2">
                            <div class="fw-bold text-black">Laravel</div>
                            <div class="fw-light text-grey">Back-End Development</div>
                        </div>
                    </div>
                </div>
                <div class="bg-teal rounded-4 p-4">
                    <div class="d-flex align-items-center">
                        <img src="https://via.placeholder.com/80x80.png?text=80x80" class="img-fluid rounded-4">
                        <div class="ps-2">
                            <div class="fw-bold text-black">Codeigniter</div>
                            <div class="fw-light text-grey">Back-End Development</div>
                        </div>
                    </div>
                </div>
                <div class="bg-teal rounded-4 p-4">
                    <div class="d-flex align-items-center">
                        <img src="https://via.placeholder.com/80x80.png?text=80x80" class="img-fluid rounded-4">
                        <div class="ps-2">
                            <div class="fw-bold text-black">HTML</div>
                            <div class="fw-light text-grey">Front-End Development</div>
                        </div>
                    </div>
                </div>
                <div class="bg-teal rounded-4 p-4">
                    <div class="d-flex align-items-center">
                        <img src="https://via.placeholder.com/80x80.png?text=80x80" class="img-fluid rounded-4">
                        <div class="ps-2">
                            <div class="fw-bold text-black">Javascript</div>
                            <div class="fw-light text-grey">Front-End Development</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- source code -->
    <div class="bg-teal py-5">
        <div class="container">
            <div class="row">
                <div class="col">
                    <!-- <div class="text-primary fw-semibold">Learn From Case Studies</div> -->
                    <!-- <div class="text-black fs-1 fw-bold">Temukan Kode Sesuai Kebutuhan Anda</div> -->
                    <div class="text-primary fw-semibold">Learn From Case Studies</div>
                    <div class="text-black fs-1 fw-bold">Pilih Kategori Sesuai Kebutuhan Anda</div>
                </div>
            </div>
            <div class="row gx-4 pt-4">
                <div class="col">
                    <div class="bg-white rounded-4 p-4">
                        <img src="https://via.placeholder.com/500x300.png?text=500x300" class="img-fluid rounded-4">
                        <div class="pt-3">
                            <div class="fw-bold text-black">Laravel Tutorial : Cara membuat model pada blade</div>
                            <div class="fw-light text-grey">Hello people spirit of learning! Dalam flutter terdapat
                                widget elevated
                                button yang</div>
                        </div>
                    </div>
                </div>
                <div class="col">
                    <div class="bg-white rounded-4 p-4">
                        <img src="https://via.placeholder.com/500x300.png?text=500x300" class="img-fluid rounded-4">
                        <div class="pt-3">
                            <div class="fw-bold text-black">UI/UX Tutorial : Cara membuat model pada blade</div>
                            <div class="fw-light text-grey">Hello people spirit of learning! Dalam flutter terdapat
                                widget elevated
                                button yang</div>
                        </div>
                    </div>
                </div>
                <div class="col">
                    <div class="bg-white rounded-4 p-4">
                        <img src="https://via.placeholder.com/500x300.png?text=500x300" class="img-fluid rounded-4">
                        <div class="pt-3">
                            <div class="fw-bold text-black">HTML Tutorial : Mahir Menggunakan Tag HTML</div>
                            <div class="fw-light text-grey">Hello people spirit of learning! Dalam flutter terdapat
                                widget elevated
                                button yang</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- animasi card left and right -->
    <div class="bg-primary">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-4 py-6">
                    <div class="text-warning fw-semibold">Dipercaya 100+ Client</div>
                    <div class="text-white fs-1 fw-bold">Join Our Community For A Better Experience</div>
                    <div class="text-white text-opacity-75 pt-2 pb-4">Bergabung bersama kami untuk menemukan solusi
                        dari
                        permasalahan sistem anda.</div>
                    <button class="btn btn-warning text-teal fw-semibold rounded-3"
                        style="--bs-btn-padding-x: 2rem; --bs-btn-padding-y: .5rem;">Send Message</button>
                </div>
                <div class="col-8">
                    <div class="row">
                        <div class="col">
                            <div class="scroll-parent">
                                <div class="scroll-element utama">
                                    <div class="bg-white rounded-4 p-4 my-3">
                                        <div class="fw-bold text-black fs-5">Banyak Pilihan</div>
                                        <div class="fw-light text-grey pt-2">Bergabung bersama kami untuk menemukan
                                            solusi dari permasalahan
                                            sistem anda.</div>
                                        <div class="d-flex align-items-center pt-3">
                                            <img src="https://via.placeholder.com/50x50.png?text=50x50"
                                                class="img-fluid rounded-circle">
                                            <div class="ps-2">
                                                <div class="fw-bold text-black" style="font-size: 14px;">Rinny</div>
                                                <div class="fw-light text-grey" style="font-size: 14px;">Mahasiswa
                                                    Tingkat Akhir</div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="bg-white rounded-4 p-4 my-3">
                                        <div class="fw-bold text-black fs-5">Banyak Pilihan</div>
                                        <div class="fw-light text-grey pt-2">Bergabung bersama kami untuk menemukan
                                            solusi dari permasalahan
                                            sistem anda.</div>
                                        <div class="d-flex align-items-center pt-3">
                                            <img src="https://via.placeholder.com/50x50.png?text=50x50"
                                                class="img-fluid rounded-circle">
                                            <div class="ps-2">
                                                <div class="fw-bold text-black" style="font-size: 14px;">Rinny</div>
                                                <div class="fw-light text-grey" style="font-size: 14px;">Mahasiswa
                                                    Tingkat Akhir</div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="bg-white rounded-4 p-4 my-3">
                                        <div class="fw-bold text-black fs-5">Banyak Pilihan</div>
                                        <div class="fw-light text-grey pt-2">Bergabung bersama kami untuk menemukan
                                            solusi dari permasalahan
                                            sistem anda.</div>
                                        <div class="d-flex align-items-center pt-3">
                                            <img src="https://via.placeholder.com/50x50.png?text=50x50"
                                                class="img-fluid rounded-circle">
                                            <div class="ps-2">
                                                <div class="fw-bold text-black" style="font-size: 14px;">Rinny</div>
                                                <div class="fw-light text-grey" style="font-size: 14px;">Mahasiswa
                                                    Tingkat Akhir</div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="bg-white rounded-4 p-4 my-3">
                                        <div class="fw-bold text-black fs-5">Banyak Pilihan</div>
                                        <div class="fw-light text-grey pt-2">Bergabung bersama kami untuk menemukan
                                            solusi dari permasalahan
                                            sistem anda.</div>
                                        <div class="d-flex align-items-center pt-3">
                                            <img src="https://via.placeholder.com/50x50.png?text=50x50"
                                                class="img-fluid rounded-circle">
                                            <div class="ps-2">
                                                <div class="fw-bold text-black" style="font-size: 14px;">Rinny</div>
                                                <div class="fw-light text-grey" style="font-size: 14px;">Mahasiswa
                                                    Tingkat Akhir</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col">
                            <div class="scroll-parent">
                                <div class="scroll-element kedua">
                                    <div class="bg-white rounded-4 p-4 my-3">
                                        <div class="fw-bold text-black fs-5">Banyak Pilihan</div>
                                        <div class="fw-light text-grey pt-2">Bergabung bersama kami untuk menemukan
                                            solusi dari permasalahan
                                            sistem anda.</div>
                                        <div class="d-flex align-items-center pt-3">
                                            <img src="https://via.placeholder.com/50x50.png?text=50x50"
                                                class="img-fluid rounded-circle">
                                            <div class="ps-2">
                                                <div class="fw-bold text-black" style="font-size: 14px;">Rinny</div>
                                                <div class="fw-light text-grey" style="font-size: 14px;">Mahasiswa
                                                    Tingkat Akhir</div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="bg-white rounded-4 p-4 my-3">
                                        <div class="fw-bold text-black fs-5">Banyak Pilihan</div>
                                        <div class="fw-light text-grey pt-2">Bergabung bersama kami untuk menemukan
                                            solusi dari permasalahan
                                            sistem anda.</div>
                                        <div class="d-flex align-items-center pt-3">
                                            <img src="https://via.placeholder.com/50x50.png?text=50x50"
                                                class="img-fluid rounded-circle">
                                            <div class="ps-2">
                                                <div class="fw-bold text-black" style="font-size: 14px;">Rinny</div>
                                                <div class="fw-light text-grey" style="font-size: 14px;">Mahasiswa
                                                    Tingkat Akhir</div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="bg-white rounded-4 p-4 my-3">
                                        <div class="fw-bold text-black fs-5">Banyak Pilihan</div>
                                        <div class="fw-light text-grey pt-2">Bergabung bersama kami untuk menemukan
                                            solusi dari permasalahan
                                            sistem anda.</div>
                                        <div class="d-flex align-items-center pt-3">
                                            <img src="https://via.placeholder.com/50x50.png?text=50x50"
                                                class="img-fluid rounded-circle">
                                            <div class="ps-2">
                                                <div class="fw-bold text-black" style="font-size: 14px;">Rinny</div>
                                                <div class="fw-light text-grey" style="font-size: 14px;">Mahasiswa
                                                    Tingkat Akhir</div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="bg-white rounded-4 p-4 my-3">
                                        <div class="fw-bold text-black fs-5">Banyak Pilihan</div>
                                        <div class="fw-light text-grey pt-2">Bergabung bersama kami untuk menemukan
                                            solusi dari permasalahan
                                            sistem anda.</div>
                                        <div class="d-flex align-items-center pt-3">
                                            <img src="https://via.placeholder.com/50x50.png?text=50x50"
                                                class="img-fluid rounded-circle">
                                            <div class="ps-2">
                                                <div class="fw-bold text-black" style="font-size: 14px;">Rinny</div>
                                                <div class="fw-light text-grey" style="font-size: 14px;">Mahasiswa
                                                    Tingkat Akhir</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- team -->
    <div class="py-5">
        <div class="container text-center">
            <div class="row">
                <div class="col">
                    <div class="text-black fs-1 fw-bold">OUR TEAM</div>
                    <div class="text-grey">Kami adalah tim yang akan menjadi solusi permasalahan sistem anda</div>
                </div>
            </div>
            <div class="row gx-4 pt-4">
                <div class="col">
                    <div class="p-4">
                        <img src="https://via.placeholder.com/150x150.png?text=150x150"
                            class="img-fluid rounded-circle">
                        <div class="pt-3">
                            <div class="fw-bold fs-3 text-black">T.A.P</div>
                            <div class="fw-light text-grey">Chief Operating Officer</div>
                        </div>
                    </div>
                </div>
                <div class="col">
                    <div class="p-4">
                        <img src="https://via.placeholder.com/150x150.png?text=150x150"
                            class="img-fluid rounded-circle">
                        <div class="pt-3">
                            <div class="fw-bold fs-3 text-black">ED</div>
                            <div class="fw-light text-grey">Chief Technology Officer</div>
                        </div>
                    </div>
                </div>
                <div class="col">
                    <div class="p-4">
                        <img src="https://via.placeholder.com/150x150.png?text=150x150"
                            class="img-fluid rounded-circle">
                        <div class="pt-3">
                            <div class="fw-bold fs-3 text-black">BOS</div>
                            <div class="fw-light text-grey">Chief Financial Officer</div>
                        </div>
                    </div>
                </div>
                <div class="col">
                    <div class="p-4">
                        <img src="https://via.placeholder.com/150x150.png?text=150x150"
                            class="img-fluid rounded-circle">
                        <div class="pt-3">
                            <div class="fw-bold fs-3 text-black">IBEL</div>
                            <div class="fw-light text-grey">Chief Marketing Officer</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- footer -->
    <footer class="bg-teal py-5">
        <div class="container">
            <div class="row">
                <div class="col-4">
                    <a href="" class=""><img src="assets/logo/logo-v2.png"
                            style="width: 50px; height: 50px;"></a>
                    <div class="text-black pt-4 pe-3">Website untuk membantu anda menemukan solusi dari permasalahan
                        sistem
                        pribadi maupun perusahaan anda.</div>
                    <div class="text-black pt-4 d-flex align-items-center"><img src="assets/icon/Untitled-2.png"
                            class="pe-1">2020-2023 hendebro</div>
                </div>
                <div class="col-2">
                    <div class="fw-semibold text-black pb-3">Company</div>
                    <div class="text-grey text-light pb-2">About</div>
                    <div class="text-grey text-light pb-2">Contact</div>
                    <div class="text-grey text-light pb-2">Office</div>
                    <div class="text-grey text-light pb-2">Instagram</div>
                </div>
                <div class="col-2">
                    <div class="fw-semibold text-black pb-3">Source Code</div>
                    <div class="text-grey text-light pb-2">Sistem Informasi</div>
                    <div class="text-grey text-light pb-2">Landing Page</div>
                    <div class="text-grey text-light pb-2">Point Of Sales (POS)</div>
                    <div class="text-grey text-light pb-2">Company Profile</div>
                    <div class="text-grey text-light pb-2">Sistem Pakar</div>
                </div>
                <div class="col-2">
                    <div class="fw-semibold text-black pb-3">Hosting</div>
                    <div class="text-grey text-light pb-2">Unlimited Hosting</div>
                    <div class="text-grey text-light pb-2">Domain</div>
                    <div class="text-grey text-light pb-2">Cloud Hosting</div>
                    <div class="text-grey text-light pb-2">Company Profile</div>
                    <div class="text-grey text-light pb-2">Sistem Pakar</div>
                </div>
                <div class="col-2">
                    <div class="fw-semibold text-black pb-3">Product</div>
                    <div class="text-grey text-light pb-2">POSBro</div>
                    <div class="text-grey text-light pb-2">GYMBro</div>
                    <div class="text-grey text-light pb-2">CLIMBro</div>
                    <div class="text-grey text-light pb-2">QRBro</div>
                </div>
            </div>
        </div>
    </footer>
    <script src="assets/node_modules/bootstrap/@popperjs/core@2.11.6/dist/umd/popper.min.js"
        integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous">
    </script>
    <script src="assets/node_modules/bootstrap/dist/js/bootstrap.min.js"
        integrity="sha384-cuYeSxntonz0PPNlHhBs68uyIAVpIIOZZ5JqeqvYYIcEL727kskC66kF92t6Xl2V" crossorigin="anonymous">
    </script>
    <script src="assets/node_modules/bootstrap/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous">
    </script>
</body>

</html>
