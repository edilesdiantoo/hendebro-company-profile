<table class="table" id="getUser">
    <thead>
        <tr>
            <th>No</th>
            <th>Menu</th>
            <th>Category Menu</th>
            <th>Keterangan</th>
            <th>Status</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $getMenuContent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td>
                    <?php echo e($key + $getMenuContent->firstItem()); ?>

                </td>
                <td><?php echo e($menu->name_menu); ?></td>
                <td><?php echo e($menu->name_category_menu); ?></td>
                <td><?php echo e($menu->keterangan); ?></td>
                <td><?php echo e($menu->status); ?></td>
                <td>
                    <a href="#" onclick="editMenuContent(<?php echo e($menu->id); ?>)">
                        <i class='bx bx-edit-alt'></i>
                    </a>
                    &nbsp;
                    <a href="#" onclick="hapusMenuContent(<?php echo e($menu->id); ?>)">
                        <i class='bx bx-trash-alt'></i>
                    </a>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<br>
<div class="row"><?php echo e(@$getMenuContent->onEachSide(2)->links()); ?></div>
<?php /**PATH C:\xampp8.2\htdocs\laravel9\resources\views/mngContent/modal/showMenuContent.blade.php ENDPATH**/ ?>