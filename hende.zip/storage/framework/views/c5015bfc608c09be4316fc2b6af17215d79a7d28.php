<table class="table" id="getUser">
    <thead>
        <tr>
            <th>No</th>
            <th>Judul</th>
            <th>Type Content</th>
            <th>Category</th>
            <th>Gambar</th>
            <th>Hit</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $getBlog; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td>
                    <?php echo e($key + $getBlog->firstItem()); ?>

                </td>
                <td><?php echo e($blog->judul); ?></td>
                <td><?php echo e($blog->menu_name); ?></td>
                <td><?php echo e($blog->category_name); ?></td>
                <td>
                    
                </td>
                <td><?php echo e($blog->hit); ?></td>
                <td>
                    <a href="#" onclick="editBlog(<?php echo e($blog->id); ?>)">
                        <i class='bx bx-edit-alt'></i>
                    </a>
                    &nbsp;
                    <a href="#" onclick="hapusBlog(<?php echo e($blog->id); ?>)">
                        <i class='bx bx-trash-alt'></i>
                    </a>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<br>
<div class="row"><?php echo e(@$getBlog->onEachSide(2)->links()); ?></div>
<?php /**PATH C:\xampp8.2\htdocs\laravel9\resources\views/mngContent/modal/showBlog.blade.php ENDPATH**/ ?>