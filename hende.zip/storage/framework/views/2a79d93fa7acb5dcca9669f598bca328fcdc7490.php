<table class="table" id="getUser">
    <thead>
        <tr>
            <th>No</th>
            <th>Nama Category</th>
            <th>Slug</th>
            <th>Ttile</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $getCategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td>
                    <?php echo e($key + $getCategory->firstItem()); ?>

                </td>
                <td><?php echo e($category->name); ?></td>
                <td><?php echo e($category->slug); ?></td>
                <td><?php echo e($category->title); ?></td>
                <td>
                    <a href="#" onclick="editCategory(<?php echo e($category->id); ?>)">
                        <i class='bx bx-edit-alt'></i>
                    </a>
                    &nbsp;
                    <a href="#" onclick="hapusCategory(<?php echo e($category->id); ?>)">
                        <i class='bx bx-trash-alt'></i>
                    </a>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<br>
<div class="row"><?php echo e(@$getCategory->onEachSide(2)->links()); ?></div>
<?php /**PATH C:\xampp8.2\htdocs\laravel9\resources\views/master/modal/showCategory.blade.php ENDPATH**/ ?>