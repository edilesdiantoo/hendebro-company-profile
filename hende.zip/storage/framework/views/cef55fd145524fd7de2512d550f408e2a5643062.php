<table class="table" id="getUser">
    <thead>
        <tr>
            <th>No</th>
            <th>Nama</th>
            <th>username</th>
            <th>Email</th>
            <th>Level</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $test_join; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $users): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td>
                    <?php echo e($key + $test_join->firstItem()); ?>

                </td>
                <td><?php echo e($users->name); ?></td>
                <td><?php echo e($users->username); ?></td>
                <td><?php echo e($users->email); ?></td>
                <td><?php echo e($users->level_name); ?></td>
                <td>
                    <a href="#" onclick="editUser(<?php echo e($users->id); ?>)">
                        <i class='bx bx-edit-alt'></i>
                    </a>
                    &nbsp;
                    <a href="#" onclick="hapusUser(<?php echo e($users->id); ?>)">
                        <i class='bx bx-trash-alt'></i>
                    </a>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<br>
<div class="row"><?php echo e(@$test_join->onEachSide(2)->links()); ?></div>
<?php /**PATH C:\xampp8.2\htdocs\laravel9\resources\views/master/modal/showUser.blade.php ENDPATH**/ ?>