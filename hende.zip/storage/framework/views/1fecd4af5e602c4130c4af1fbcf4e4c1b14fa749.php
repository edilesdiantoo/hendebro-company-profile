<table class="table" id="getUser">
    <thead>
        <tr>
            <th>No</th>
            <th>Judul</th>
            <th>Type Content</th>
            <th>Category</th>
            <th>Gambar</th>
            <th>Keterangan</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $getScode; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $scode): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td>
                    <?php echo e($key + $getScode->firstItem()); ?>

                </td>
                <td><?php echo e($scode->judul); ?></td>
                <td><?php echo e($scode->menu_name); ?></td>
                <td><?php echo e($scode->category_name); ?></td>
                <td>
                    
                </td>
                <td><?php echo e($scode->keterangan); ?></td>
                <td>
                    <a href="#" onclick="editScode(<?php echo e($scode->id); ?>)">
                        <i class='bx bx-edit-alt'></i>
                    </a>
                    &nbsp;
                    <a href="#" onclick="hapusScode(<?php echo e($scode->id); ?>)">
                        <i class='bx bx-trash-alt'></i>
                    </a>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<br>
<div class="row"><?php echo e(@$getScode->onEachSide(2)->links()); ?></div>
<?php /**PATH C:\xampp8.2\htdocs\laravel9\resources\views/mngContent/modal/showScode.blade.php ENDPATH**/ ?>