<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class CategoryMenuController extends Controller
{
    //
}
