<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class HdrController extends Controller
{
    //
}
